#Q1

Y<-c(12,90,80,5,63,15,67,22,56,33)
X<-c(50,150,63,10,63,8,56,19,63,19)
N<-X+Y
n<-length(Y)

#a

alpha<-Y+1/2
beta<-N-Y+1/2

theta.Y<-rbeta(n,alpha,beta)

# Set the confidence level
cl <- 0.95

# Calculate the lower and upper quantiles
lower_quantile <- qbeta((1 - cl) / 2, alpha, beta)
upper_quantile <- qbeta(1 - (1 - cl) / 2, alpha, beta)


#b
p<-Y/N

mean.p<-mean(p)
var.p<-var(p)

M<-mean.p
V<-var.p

a<-(((M^2)*(1-M))-M*V)/V
b<-(M*(1-M)^2-(1-M)*V)/V

#c

alpha2<-a+Y
beta2<-N-Y+b

# Set the confidence level
cl <- 0.95

# Calculate the lower and upper quantiles
lower_quantile2<- qbeta((1 - cl) / 2, alpha2, beta2)
upper_quantile2 <- qbeta(1 - (1 - cl) / 2, alpha2, beta2)

#Q2
n<-3
Y<-c(12,10,22)
sigma<-diag(3,3,10)
library(mvtnorm)


density<-function(x)
{
  d<-dmvnorm(x, mean = Y, sigma = SIGMA)
  return(d)
}

#a

integrate(density,-1e6,1e6)


exp(-(sum((Y-x)/sigma)^2)/2)

prod(dnorm(x,Y,sigma))

#Q3
sigmaSq.update <- function(n,Y, a, b)
{
  sigmaSq.inv<-rgamma(n,a+1/2,b+(Y^2)/2)
  sigmaSq<-sigmaSq.inv
  return(sigmaSq)
}

b.update <- function(sigmaSq)
{
  b<-rgamma(1,1,b+sum(1/sigmaSq))
  return(b)
}

MCMC <- function(n,Y, b.init, sigmaSq.init, a, iters){
  # chain initiation
  b<-b.init
  sigmaSq <- sigmaSq.init
  # define chains
  b.chain <- rep(NA, iters)
  sigmaSq.chain <- matrix(NA, iters,n)
  # start MCMC
  for(i in 1:iters){
    b <- b.update(sigmaSq)
    sigmaSq <- sigmaSq.update(n,Y, a, b)
    b.chain[i] <- b
    sigmaSq.chain[i,] <- sigmaSq
  }
  # return chains
  out <- list(b.chain = b.chain,
              sigmaSq.chain = sigmaSq.chain)
  return(out)}

N<-10
Y<-seq(1:10)
a<-10

MCMC.out <- MCMC(n=N,Y = Y,
                 b.init = 0.1,
                 sigmaSq.init = var(Y),
                 a = a,
                 iters = 30000)
plot(MCMC.out$b.chain, xlab = "Iteration", ylab = "b", type = "l")
plot(MCMC.out$sigmaSq.chain[,1], xlab = "Iteration", ylab = "sigmaSq", type = "l")

N<-10
Y<-seq(1:10)
a<-1

MCMC.out <- MCMC(n=N,Y = Y,
                 b.init = 0.1,
                 sigmaSq.init = var(Y),
                 a = a,
                 iters = 30000)
plot(MCMC.out$b.chain, xlab = "Iteration", ylab = "b", type = "l")
plot(MCMC.out$sigmaSq.chain, xlab = "Iteration", ylab = "sigmaSq", type = "l")


library(rjags)

n<-10
Y<-seq(1:10)
a<-10

data <- list(Y = Y, n = n)

model_string <- textConnection("model{

   # Likelihood
   for(i in 1:n){
     Y[i] ~ dnorm(0,sigma_sq[i])
   }

   # Priors
   for(i in 1:n){
     sigma_sq[i] ~ dgamma(10,b)
   }
   b ~ dgamma(1,1)

 }")

model <- jags.model(model_string, data = data,
                    n.chains = 2, quiet = TRUE)

update(model, 10000, progress.bar = "none")

samples <- coda.samples(model, variable.names = "sigma_sq", 
                        n.iter = 30000, thin = 2, progress.bar = "none")

summary(samples)

plot(samples[,1])

#Q4
m<-rnorm(1,0,10)
m<-0
theta<-rbeta(10,Y+exp(m)*Q,N-Y+exp(m)*(1-Q))
theta.chain <- matrix(NA, 10,10)
theta.chain[1,] <- theta


theta.update <- function(n,Y,Q,N,m)
{
  theta<-rbeta(n,Y+exp(m)*Q,N-Y+exp(m)*(1-Q))
  return(theta)
}

m.update <- function()
{
  m<-rnorm(1,0,10)
  return(m)
}

MCMC <- function(n,Y,Q,N, m.init, theta.init, iters){
  # chain initiation
  m<-m.init
  theta <- theta.init
  # define chains
  m.chain <- rep(NA, iters)
  theta.chain <- matrix(NA, iters,n)
  # start MCMC
  for(i in 1:iters){
    m <- m.update()
    theta <- theta.update(n,Y,Q,N, m)
    m.chain[i] <- m
    theta.chain[i,] <- theta
  }
  # return chains
  out <- list(m.chain = m.chain,
              theta.chain = theta.chain)
  return(out)}

n<-10
Q<-c(0.845, 0.847, 0.880, 0.674, 0.909, 0.898, 0.770, 0.801, 0.802, 0.875)
Y<-c(64, 72, 55, 27, 75, 24, 28, 66, 40, 13)
X<-c(75, 95, 63, 39, 83, 26, 41, 82, 54, 16)
N<-Y+X

MCMC.out <- MCMC(n=n,Y = Y,
                 Q=Q,
                 N=N,
                 m.init = 0,
                 theta.init = 1-var(Y)/mean(Y),
                 iters = 30000)
plot(MCMC.out$m.chain, xlab = "Iteration", ylab = "m", type = "l")
plot(MCMC.out$theta.chain[,1], xlab = "Iteration", ylab = "theta1", type = "l")

confidence_interval<-matrix(NA,2,11)

for(i in 1:10)
{
  confidence_interval[,i] <- quantile(MCMC.out$theta.chain[,i], c(0.025, 0.975))
}
confidence_interval[,11]<-quantile(MCMC.out$m.chain, c(0.025, 0.975))



library(rjags)

n<-10
Q<-c(0.845, 0.847, 0.880, 0.674, 0.909, 0.898, 0.770, 0.801, 0.802, 0.875)
Y<-c(64, 72, 55, 27, 75, 24, 28, 66, 40, 13)
X<-c(75, 95, 63, 39, 83, 26, 41, 82, 54, 16)
N<-Y+X

data <- list(Y = Y,Q=Q,N=N, n = n)

model_string <- textConnection("model{

   # Likelihood
   for(i in 1:n){
     Y[i] ~ dbin(theta[i],N[i])
   }

   # Priors
   for(i in 1:n){
     theta[i] ~ dbeta(exp(m)*Q[i],exp(m)*(1-Q[i]))
   }
   m ~ dnorm(0,10)

 }")

model <- jags.model(model_string, data = data,
                    n.chains = 2, quiet = TRUE)

update(model, 10000, progress.bar = "none")

samples <- coda.samples(model, variable.names = "theta", 
                        n.iter = 30000, thin = 2, progress.bar = "none")
samples2 <- coda.samples(model, variable.names = "m", 
                         n.iter = 30000, thin = 2, progress.bar = "none")

summary(samples)[2]

plot(samples[,1])


summary(samples)[2]
